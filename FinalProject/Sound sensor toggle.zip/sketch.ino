
#define SOUND_IN  7
#define LED_RED   4

bool soundState = false;

void setup() {
  pinMode(SOUND_IN, INPUT);
  pinMode(LED_RED, OUTPUT);
}

void loop() {
  if(digitalRead(SOUND_IN)){
    digitalWrite(LED_RED, !digitalRead(LED_RED));
    delay(500);
  }
}
